export function PlantDrawing() {
  return (
    <figure className="overflow-hidden rounded-card border border-line bg-ink text-foam shadow-[0_18px_40px_rgba(11,19,43,0.16)]">
      <figcaption className="flex items-baseline justify-between gap-3 px-5 pt-5">
        <span className="font-display text-xs font-semibold tracking-[0.16em] text-mint uppercase">
          Plant ticket
        </span>
        <span className="text-xs text-foam-dim">Amagba Junction</span>
      </figcaption>
      <div className="px-5 pt-3">
        <p className="font-display text-4xl font-bold tracking-tight">1.5 MT</p>
        <p className="mt-1 text-sm text-foam-dim">LPG storage on the Sapele Road axis</p>
      </div>
      <svg
        viewBox="0 0 640 250"
        className="mt-2 h-auto w-full"
        role="img"
        aria-label="Diagram of the BX Energies storage tank, scale and cylinders"
      >
        <line x1="36" y1="196" x2="604" y2="196" className="stroke-foam-dim" strokeWidth="1.5" />
        <ellipse cx="210" cy="128" rx="132" ry="48" className="fill-primary stroke-foam" strokeWidth="2" />
        <rect x="78" y="128" width="264" height="46" className="fill-primary" />
        <ellipse cx="210" cy="174" rx="132" ry="22" className="fill-cyan/80" />
        <path d="M150 104h120" className="stroke-mint" strokeWidth="3" strokeLinecap="round" />
        <circle cx="168" cy="104" r="5" className="fill-mint" />
        <rect x="400" y="78" width="46" height="118" rx="23" className="fill-foam" />
        <rect x="458" y="96" width="40" height="100" rx="20" className="fill-foam-dim" />
        <rect x="508" y="112" width="34" height="84" rx="17" className="fill-cyan" />
        <rect x="392" y="188" width="168" height="8" rx="2" className="fill-mint" />
        <path d="M430 188v-14M522 188v-14" className="stroke-foam" strokeWidth="2" />
        <text x="78" y="228" fill="currentColor" className="fill-foam-dim text-[18px]">
          Tank · digital scale · cylinders
        </text>
      </svg>
    </figure>
  );
}
