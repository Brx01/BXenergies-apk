import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "BX Energies | Cooking Gas Refill & Delivery in Amagba & Benin City" },
      {
        name: "description",
        content:
          "Order 100% digitally metered LPG cooking gas refills (₦1,350/kg), brand-new cylinders, and fast doorstep delivery across Amagba Junction, Amagba GRA, BIU, Limit Road, Aruogba and Benin City.",
      },
      {
        name: "keywords",
        content:
          "cooking gas delivery Benin City, LPG gas plant Amagba, gas refill near BIU Benin, BX Energies, buy gas cylinder Benin City, cooking gas Amagba GRA, gas delivery Sapele Road Benin",
      },
      { name: "robots", content: "index, follow" },
      { name: "geo.region", content: "NG-ED" },
      { name: "geo.placename", content: "Benin City" },
      { name: "geo.position", content: "6.2650;5.6050" },
      { name: "ICBM", content: "6.2650, 5.6050" },
      { name: "theme-color", content: "#0B132B" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "canonical", href: "https://bxenergies.com" },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Source+Sans+3:ital,wght@0,400;0,600;0,700;1,400&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
